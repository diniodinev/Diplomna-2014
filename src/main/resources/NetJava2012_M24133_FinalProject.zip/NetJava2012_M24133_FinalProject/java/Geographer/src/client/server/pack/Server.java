package client.server.pack;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.JOptionPane;

public class Server {

	public static ServerSocket serverSocket = null;
	private Socket client = null;
	private int maxConnections;
	private int listenPort;
	public static AtomicBoolean isServerRunning = new AtomicBoolean(false);

	public Server() {
	}

	public Server(int listenPort, int maxConnections) {
		this.maxConnections = maxConnections;
		this.listenPort = listenPort;
	}

	void acceptConnection() {
		try {
			serverSocket = new ServerSocket(listenPort, maxConnections);

			while (Server.isServerRunning.get()) {
				client = serverSocket.accept();
				handleConnection(client);
			}
		} catch (SocketException e) {
			JOptionPane.showMessageDialog(null, "The server is stopped !");

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			tearDownConnection();
		}
	}

	private void handleConnection(Socket clientSocket) {
		PooledConnectionHandler.processRequest(clientSocket);
	}

	// Organization of handlers
	public void setUpHandlers() {
		for (int i = 0; i < maxConnections; i++) {
			PooledConnectionHandler currentHandler = new PooledConnectionHandler();
			new Thread(currentHandler, "Handler " + i).start();

		}

	}

	private void tearDownConnection() {
		try {
			serverSocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
