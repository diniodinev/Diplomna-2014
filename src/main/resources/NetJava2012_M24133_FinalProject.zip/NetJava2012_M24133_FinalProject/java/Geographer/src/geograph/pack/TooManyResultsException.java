package geograph.pack;

public class TooManyResultsException extends Exception {

	public TooManyResultsException() {
	}

	public TooManyResultsException(String msg) {
		super(msg);
	}

}
