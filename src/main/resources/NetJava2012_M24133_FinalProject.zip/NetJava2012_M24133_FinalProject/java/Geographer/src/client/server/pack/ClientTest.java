package client.server.pack;

public class ClientTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//Client prben = new Client();
		//prben.connectToServer("127.0.0.1", 3000);
		//prben.tearDownConnection();
	}

}
