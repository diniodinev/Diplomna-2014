package geograph.pack;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import sun.org.mozilla.javascript.internal.ast.ForInLoop;

public class GeoImages implements Serializable {
	private String name;
	private int length;
	private byte[] data;
	private int mapScale;
	private ResultSet resultSet;

	public GeoImages(String name, int length, byte[] data, int mapScale) {
		this.name = name;
		this.length = length;
		this.data = data;
		this.mapScale = mapScale;
	}

	public GeoImages() {
	}

	/**
	 * @param resultSet
	 *            From which we want to read in the resultSet we must have one
	 *            row with String name, int length, byte[] data, int mapScale
	 */
	public GeoImages(ResultSet resultSet) {
		// name, length, data, mapScale
		try {
			if (resultSet.next()) {
				setName(resultSet.getString(1));
				setLength(resultSet.getInt(2));
				setData(resultSet.getBytes(3));
				setMapScale(resultSet.getInt(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = (name != null) ? name : "";
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = (length > 0) ? length : 0;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = new byte[data.length];
		if (data == null) {
			return;
		}
		for (int i = 0; i < data.length; i++) {
			this.data[i] = data[i];
		}
	}

	public int getMapScale() {
		return mapScale;
	}

	public void setMapScale(int mapScale) {

		this.mapScale = (mapScale > 0) ? mapScale : 0;
	}
}
