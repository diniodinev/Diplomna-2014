/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geograph.pack;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

import sun.org.mozilla.javascript.internal.ast.TryStatement;

import client.server.pack.Server;
import client.server.pack.StartServer;

/**
 * 
 * @author Cannibal
 */
public class ServerFrame extends javax.swing.JFrame {

	/**
	 * Creates new form ServerFrame
	 */
	public ServerFrame() {
		initComponents();
		addProperties();

	}

	public void addProperties() {
		// Add checkBox properties
		ButtonGroup group = new ButtonGroup();
		group.add(chBoxURL);
		chBoxURL.setSelected(true);
		group.add(chBoxDisc);
		txtFieldURL.setEditable(true);
		txtFieldDisc.setEditable(false);
	}

	private boolean checkData() {
		if (chBoxURL.isSelected() && !isURLFileValid(txtFieldURL.getText())) {
			return false;
		}
		if (chBoxDisc.isSelected() && !isDiscFileValid()) {
			return false;
		}
		if (!checkMapNameValidity()) {
			return false;
		}
		;
		if (!checkScale()) {
			return false;
		}
		return true;
	}

	private void clearFields() {
		txtFieldURL.setText("");
		chBoxURL.doClick();
		txtFieldMapName.setText("");
		txtFieldScale.setText("");
	}

	private boolean checkMapNameValidity() {
		if (txtFieldMapName.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(this, "The map name is empty",
					"Error", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		;
		return true;
	}

	private boolean checkScale() {
		if (txtFieldScale.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(this, "The scale value is empty",
					"Error", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		;
		if (!isInteger(txtFieldScale.getText().trim())) {
			JOptionPane.showMessageDialog(this, "The scale value is incorrect",
					"Error", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		;
		if (Integer.parseInt(txtFieldScale.getText().trim()) < 2) {
			JOptionPane.showMessageDialog(this,
					"The scale value is incorrect. It must be greater than 2",
					"Error", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		if (Integer.parseInt(txtFieldScale.getText().trim()) > 2000000) {
			JOptionPane
					.showMessageDialog(
							this,
							"The scale value is incorrect. It must be less than 2 milions",
							"Error", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}

	private boolean isInteger(String input) {
		try {
			Integer.parseInt(input);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	private void browsFile() {
		JFileChooser fileopen = new JFileChooser();
		fileopen.setAcceptAllFileFilterUsed(false);
		FileFilter filter = new FileNameExtensionFilter(
				"Picture files only .jpg, .jpeg, .bmp ", "jpg", "jpeg", "bmp");
		fileopen.addChoosableFileFilter(filter);

		int ret = fileopen.showDialog(null, "Open file");

		if (ret == JFileChooser.APPROVE_OPTION) {
			File file = fileopen.getSelectedFile();
			txtFieldDisc.setText(file.getAbsolutePath());
			chBoxDisc.doClick();
		}
	}

	// Check if the Disc field infomration is correct
	private boolean isDiscFileValid() {
		FileInputStream fileInputStream;
		try {
			fileInputStream = new FileInputStream(txtFieldDisc.getText().trim());
			return true;
		} catch (FileNotFoundException ex) {
			JOptionPane
					.showMessageDialog(
							this,
							"The file path that you choose is invalid for this file do not exist",
							"File not found", JOptionPane.ERROR_MESSAGE);
			return false;
		} catch (SecurityException e) {
			JOptionPane.showMessageDialog(this,
					"You hava no permission to read from the file you choose.",
					"File not found", JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}

	// Check if the URL field infomration is correct

	private boolean isURLFileValid(String urlLocation) {
		try {

			URL url = new URL(urlLocation);
			URLConnection conn = url.openConnection();
			conn.connect();
			String urlType = conn.getContentType();
			if (urlType.contains("image/jpeg") || urlType.contains("image/jpg")
					|| urlType.contains("image/bmp")) {
				return true;
			} else {
				JOptionPane
						.showMessageDialog(
								this,
								"The entered URL is not a picture or is not in a propriate picture pormat jgp, jpeg or bmp",
								"Error in picture URL",
								JOptionPane.ERROR_MESSAGE);
				return false;
			}
		} catch (MalformedURLException e) {
			JOptionPane.showMessageDialog(this, "The entered URL is wrong",
					"Error in picture URL", JOptionPane.ERROR_MESSAGE);
			return false;
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "The entered URL is wrong",
					"Error in picture URL", JOptionPane.ERROR_MESSAGE);
			return false;
		}

	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always
	 * regenerated by the Form Editor.
	 */
	@SuppressWarnings("unchecked")
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		panelServerButtons = new javax.swing.JPanel();
		btvStopServer = new javax.swing.JButton();
		btvStartServer = new javax.swing.JButton();
		btnNewMap = new javax.swing.JButton();
		pnlNewMap = new javax.swing.JPanel();
		txtFieldURL = new javax.swing.JTextField();
		chBoxURL = new javax.swing.JCheckBox();
		chBoxDisc = new javax.swing.JCheckBox();
		txtFieldDisc = new javax.swing.JTextField();
		btnBrowse = new javax.swing.JButton();
		txtFieldMapName = new javax.swing.JTextField();
		txtFieldScale = new javax.swing.JTextField();
		lblMapName = new javax.swing.JLabel();
		lblScale = new javax.swing.JLabel();
		btnSaveMap = new javax.swing.JButton();
		btnPutCordinate = new javax.swing.JButton();

		// NewPicturePanell Elements
		jScrollPane1 = new javax.swing.JScrollPane();
		listModel = new DefaultListModel();
		listMaps = new javax.swing.JList(listModel);
		pnlPicturePanel = new ImagePanel();
		lblX = new javax.swing.JLabel();
		txtFieldXCoordinate = new javax.swing.JTextField();
		lblYCoordinate = new javax.swing.JLabel();
		txtFieldYCoordinate = new javax.swing.JTextField();
		btnSaveCoordinate = new javax.swing.JButton();
		lblQestionName = new javax.swing.JLabel();
		txtFieldQuestionName = new javax.swing.JTextField();
		lblQuestionInfo = new javax.swing.JLabel();
		txtFieldQuestionInfo = new javax.swing.JTextField();
		pnlNewPictureMap = new javax.swing.JPanel();
		pnlNewPictureMapLayout = new javax.swing.GroupLayout(pnlNewPictureMap);
		cardLayout = new CardLayout();
		pnlCard = new JPanel(cardLayout);
		pictureJFrame = new JFrame();
		pnlNewMapLayout = new javax.swing.GroupLayout(pnlNewMap);

		// DBActions
		connectivity = new DBConectivity();
		connectivity.connect();
		allMapsNameQuery = new String("select name from geoImage");

		pnlCard.add(pnlNewMap, "NewMap");
		pnlCard.add(pnlNewPictureMap, "NewPicture");

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setResizable(false);

		jPanel1.setForeground(new java.awt.Color(204, 204, 255));

		panelServerButtons.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(204, 204, 255)));
		panelServerButtons.setForeground(new java.awt.Color(153, 0, 153));

		btvStopServer.setText("Stop Server");
		btvStopServer.setEnabled(false);
		btvStopServer.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btvStartServer.setEnabled(true);
				btvStopServer.setEnabled(false);
				btvStopServerActionPerformed(evt);
			}
		});

		btvStartServer.setText("Start Server");

		btvStartServer.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btvStartServer.setEnabled(false);
				btvStopServer.setEnabled(true);
				btvStartServerActionPerformed(evt);
			}
		});

		btnNewMap.setText("New Map");
		btnNewMap.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnNewMapActionPerformed(evt);
			}
		});

		btnPutCordinate.setText("Put coordinates");

		javax.swing.GroupLayout panelServerButtonsLayout = new javax.swing.GroupLayout(
				panelServerButtons);
		panelServerButtons.setLayout(panelServerButtonsLayout);
		panelServerButtonsLayout
				.setHorizontalGroup(panelServerButtonsLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								panelServerButtonsLayout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(btnNewMap)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addComponent(btnPutCordinate)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addComponent(btvStartServer)
										.addGap(18, 18, 18)
										.addComponent(btvStopServer)
										.addGap(18, 18, 18)));
		panelServerButtonsLayout
				.setVerticalGroup(panelServerButtonsLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								panelServerButtonsLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												panelServerButtonsLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																btvStartServer)
														.addComponent(
																btvStopServer)
														.addComponent(btnNewMap)
														.addComponent(
																btnPutCordinate))
										.addContainerGap(66, Short.MAX_VALUE)));

		pnlNewMap.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(204, 204, 255)));

		// NewPicture pannel Start
		listMaps.setToolTipText("The list of maps in the DB");
		jScrollPane1.setViewportView(listMaps);

		pnlPicturePanel.setBorder(javax.swing.BorderFactory
				.createLineBorder(new java.awt.Color(204, 204, 255)));

		pnlPicturePanel.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent event) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent event) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent event) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseEntered(MouseEvent event) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent event) {
				Point clickedPoint = event.getPoint();
				txtFieldXCoordinate.setText(String.valueOf((int) clickedPoint
						.getX()));
				txtFieldYCoordinate.setText(String.valueOf((int) clickedPoint
						.getY()));
			}
		});

		javax.swing.GroupLayout pnlPicturePanelLayout = new javax.swing.GroupLayout(
				pnlPicturePanel);
		pnlPicturePanel.setLayout(pnlPicturePanelLayout);
		pnlPicturePanelLayout.setHorizontalGroup(pnlPicturePanelLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 0, Short.MAX_VALUE));
		pnlPicturePanelLayout.setVerticalGroup(pnlPicturePanelLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 121, Short.MAX_VALUE));

		lblX.setText("X:");

		txtFieldXCoordinate.setEditable(false);

		lblYCoordinate.setText("Y:");

		txtFieldYCoordinate.setEditable(false);

		btnSaveCoordinate.setText("Save");
		btnSaveCoordinate
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						btnSaveCoordinateActionPerformed(evt);
					}
				});

		lblQestionName.setText("Question Name");

		lblQuestionInfo.setText("Question Info");

		pnlNewPictureMap.setLayout(pnlNewPictureMapLayout);
		pnlNewPictureMapLayout
				.setHorizontalGroup(pnlNewPictureMapLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								pnlNewPictureMapLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												pnlNewPictureMapLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																pnlPicturePanel,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																Short.MAX_VALUE)
														.addGroup(
																pnlNewPictureMapLayout
																		.createSequentialGroup()
																		.addComponent(
																				lblX)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				txtFieldXCoordinate,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				64,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				lblYCoordinate)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				txtFieldYCoordinate,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				64,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addComponent(
																				btnSaveCoordinate))
														.addGroup(
																pnlNewPictureMapLayout
																		.createSequentialGroup()
																		.addGroup(
																				pnlNewPictureMapLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								lblQestionName)
																						.addComponent(
																								lblQuestionInfo))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				pnlNewPictureMapLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								txtFieldQuestionName)
																						.addComponent(
																								txtFieldQuestionInfo))))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jScrollPane1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												112,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap()));
		pnlNewPictureMapLayout
				.setVerticalGroup(pnlNewPictureMapLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								pnlNewPictureMapLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												pnlNewPictureMapLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																jScrollPane1)
														.addGroup(
																pnlNewPictureMapLayout
																		.createSequentialGroup()
																		.addComponent(
																				pnlPicturePanel,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				pnlNewPictureMapLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								lblX)
																						.addComponent(
																								txtFieldXCoordinate,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								lblYCoordinate)
																						.addComponent(
																								txtFieldYCoordinate,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								btnSaveCoordinate))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				pnlNewPictureMapLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								lblQestionName)
																						.addComponent(
																								txtFieldQuestionName,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.PREFERRED_SIZE))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addGroup(
																				pnlNewPictureMapLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								lblQuestionInfo)
																						.addComponent(
																								txtFieldQuestionInfo,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.PREFERRED_SIZE))))
										.addContainerGap()));
		// New Picture pannel Stop

		chBoxURL.setText("From URL");
		chBoxURL.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				chBoxURLActionPerformed(evt);
			}
		});

		chBoxDisc.setText("From Disc");
		chBoxDisc.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				chBoxDiscActionPerformed(evt);
			}
		});

		btnBrowse.setText("Browse...");
		btnBrowse.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnBrowseActionPerformed(evt);
			}
		});
		btnPutCordinate.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnPutCoordinatesActionPerformed(evt);
			}
		});
		txtFieldMapName.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				txtFieldMapNameActionPerformed(evt);
			}
		});

		txtFieldScale
				.setToolTipText("The scale must be between 2 and 2,000,000");

		lblMapName.setText("Map Name");

		lblScale.setText("Real width");
		lblScale.setToolTipText("The real width of the surface in km that the map represents.");

		btnSaveMap.setText("Save Map");
		btnSaveMap.setMaximumSize(new java.awt.Dimension(89, 23));
		btnSaveMap.setMinimumSize(new java.awt.Dimension(89, 23));
		btnSaveMap.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnSaveMapActionPerformed(evt);
			}
		});
		// Listener for clicking o the list with the maps
		listMaps.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent mouseEvent) {
				ResultSet result = null;
				JList theList = (JList) mouseEvent.getSource();
				if (mouseEvent.getClickCount() == 2) {
					int index = theList.locationToIndex(mouseEvent.getPoint());
					if (index >= 0) {
						Object o = theList.getModel().getElementAt(index);
						putInfoForCurrentMap(o.toString());

					}
				}
			}
		});

		// New picture pannel

		pnlNewMap.setLayout(pnlNewMapLayout);
		pnlNewMapLayout
				.setHorizontalGroup(pnlNewMapLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								pnlNewMapLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												pnlNewMapLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING,
																false)
														.addComponent(
																txtFieldURL)
														.addComponent(
																txtFieldDisc,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																266,
																Short.MAX_VALUE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												pnlNewMapLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																pnlNewMapLayout
																		.createSequentialGroup()
																		.addComponent(
																				chBoxURL,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addGap(124,
																				124,
																				124))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																pnlNewMapLayout
																		.createSequentialGroup()
																		.addComponent(
																				chBoxDisc,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addGap(18,
																				18,
																				18)
																		.addGroup(
																				pnlNewMapLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								btnSaveMap,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								89,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								btnBrowse))
																		.addGap(21,
																				21,
																				21))))
						.addGroup(
								pnlNewMapLayout
										.createSequentialGroup()
										.addGap(19, 19, 19)
										.addGroup(
												pnlNewMapLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																lblMapName,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																61,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(lblScale))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												pnlNewMapLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																txtFieldScale,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																100,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																txtFieldMapName,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																191,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(0, 202, Short.MAX_VALUE)));
		pnlNewMapLayout
				.setVerticalGroup(pnlNewMapLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								pnlNewMapLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												pnlNewMapLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																txtFieldURL,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																chBoxURL,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																Short.MAX_VALUE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												pnlNewMapLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.CENTER)
														.addComponent(
																txtFieldDisc,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																chBoxDisc,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																29,
																Short.MAX_VALUE)
														.addComponent(btnBrowse))
										.addGap(28, 28, 28)
										.addGroup(
												pnlNewMapLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																txtFieldMapName,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																lblMapName))
										.addGap(18, 18, 18)
										.addGroup(
												pnlNewMapLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																txtFieldScale,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(lblScale))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(
												btnSaveMap,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(23, 23, 23)));

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																pnlCard,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																Short.MAX_VALUE)
														.addComponent(
																panelServerButtons,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																Short.MAX_VALUE))
										.addContainerGap()));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												pnlCard,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(
												panelServerButtons,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup()
						.addContainerGap()
						.addComponent(jPanel1,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}// </editor-fold>

	private void putInfoForCurrentMap(String mapName) {
		DBImage image = new DBImage();
		GeoImages dataForMap = image.getImageData(connectivity.getConnection(),
				mapName);

		pnlPicturePanel.putPicture(dataForMap.getData());
		pnlPicturePanel.repaint();
	}

	private void btvStopServerActionPerformed(java.awt.event.ActionEvent evt) {
		try {
			if (Server.serverSocket != null) {
				Server.serverSocket.close();
				Server.isServerRunning.set(false);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//
	}

	private void btvStartServerActionPerformed(java.awt.event.ActionEvent evt) {
		Server.isServerRunning.set(true);
		new Thread(new StartServer()).start();

	}

	private void btnNewMapActionPerformed(java.awt.event.ActionEvent evt) {
		clearFields();
		CardLayout cl = (CardLayout) (pnlCard.getLayout());
		cl.show(pnlCard, "NewMap");
		putOldNewMapLittkeSize();
		btnPutCordinate.setEnabled(true);
	}

	private void btnPutCoordinatesActionPerformed(java.awt.event.ActionEvent evt) {
		ResultSet mapNames = connectivity.executeDBQuery(allMapsNameQuery);
		byte[] clearArray = new byte[0];
		// Clean elements from Jlist
		listModel.removeAllElements();
		// Clean QestionName and Infro Fields
		cleanPutCoordinatesFields();
		try {
			while (mapNames.next()) {
				listModel.addElement(mapNames.getObject(1));
			}

			CardLayout cl = (CardLayout) (pnlCard.getLayout());
			putNewMapBigSize();
			pnlPicturePanel.putPicture(clearArray);
			pnlPicturePanel.repaint();
			cl.show(pnlCard, "NewPicture");
			btnPutCordinate.setEnabled(false);
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(this, "Can not connect to DB",
					"Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void chBoxURLActionPerformed(java.awt.event.ActionEvent evt) {
		txtFieldURL.setEditable(true);
		txtFieldDisc.setEditable(false);
		txtFieldDisc.setText("");

	}

	private void chBoxDiscActionPerformed(java.awt.event.ActionEvent evt) {
		txtFieldDisc.setEditable(true);
		txtFieldURL.setEditable(false);
		txtFieldURL.setText("");

	}

	private void btnBrowseActionPerformed(java.awt.event.ActionEvent evt) {
		browsFile();
	}

	// tova
	private void btnSaveCoordinateActionPerformed(java.awt.event.ActionEvent evt) {

		if (listMaps.getSelectedIndex() != -1 && checkSaveCoordinateFields()) {
			DBPlayingData writeToDB = new DBPlayingData();
			writeToDB.insertData(connectivity.getConnection(), Integer
					.parseInt(txtFieldXCoordinate.getText()), Integer
					.parseInt(txtFieldYCoordinate.getText()),
					txtFieldQuestionName.getText(), txtFieldQuestionInfo
							.getText(), listMaps.getSelectedValue().toString());
		}
		cleanPutCoordinatesFields();

	}

	private boolean checkSaveCoordinateFields() {
		if (txtFieldQuestionName.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(this,
					"The Qestion name field is empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
		if (txtFieldQuestionInfo.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(this,
					"The Qestion Info field is empty", "Error",
					JOptionPane.ERROR_MESSAGE);
			return false;
		}
		if (Integer.parseInt(txtFieldXCoordinate.getText()) == 0
				|| Integer.parseInt(txtFieldYCoordinate.getText()) == 0) {
			JOptionPane
					.showMessageDialog(
							this,
							"You must open a map and select a point different from (0;0)",
							"Error", JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}

	private void cleanPutCoordinatesFields() {
		txtFieldXCoordinate.setText("0");
		txtFieldYCoordinate.setText("0");
		txtFieldQuestionName.setText("");
		txtFieldQuestionInfo.setText("");
	}

	private void txtFieldMapNameActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void btnSaveMapActionPerformed(java.awt.event.ActionEvent evt) {
		if (checkData()) {
			DBConectivity connection = new DBConectivity();
			connection.connect();
			DBImage imageSave = new DBImage();
			imageSave.insertImage(connection.getConnection(),
					getUrlOrDickLocation(), txtFieldMapName.getText().trim(),
					Integer.parseInt(txtFieldScale.getText().trim()));
			clearFields();
		}
	}

	private String getUrlOrDickLocation() {
		if (chBoxDisc.isSelected()) {
			return txtFieldDisc.getText().trim();
		} else {
			return txtFieldURL.getText().trim();
		}
	}

	// New picture Pannel

	private void putNewMapBigSize() {
		this.setMaximumSize(new java.awt.Dimension(784, 680));
		this.setMinimumSize(new java.awt.Dimension(784, 680));
		this.setPreferredSize(new java.awt.Dimension(784, 680));
		pnlPicturePanel.setMaximumSize(new java.awt.Dimension(624, 403));
		pnlPicturePanel.setMinimumSize(new java.awt.Dimension(624, 403));
		pnlPicturePanel.setPreferredSize(new java.awt.Dimension(624, 403));
	}

	private void putOldNewMapLittkeSize() {

		this.setMaximumSize(new java.awt.Dimension(511, 391));
		this.setMinimumSize(new java.awt.Dimension(511, 391));
		this.setPreferredSize(new java.awt.Dimension(511, 391));
		pnlPicturePanel.setMaximumSize(new java.awt.Dimension(357, 123));
		pnlPicturePanel.setMinimumSize(new java.awt.Dimension(357, 123));
		pnlPicturePanel.setPreferredSize(new java.awt.Dimension(357, 123));
		pnlCard.setMaximumSize(new java.awt.Dimension(487, 237));
		pnlCard.setMinimumSize(new java.awt.Dimension(487, 237));
		pnlCard.setPreferredSize(new java.awt.Dimension(487, 237));
		this.pack();
	}

	/**
	 * @param args
	 *            the command line arguments
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		// <editor-fold defaultstate="collapsed"
		// desc=" Look and feel setting code (optional) ">
		/*
		 * If Nimbus (introduced in Java SE 6) is not available, stay with the
		 * default look and feel. For details see
		 * http://download.oracle.com/javase
		 * /tutorial/uiswing/lookandfeel/plaf.html
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager
					.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(ServerFrame.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(ServerFrame.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(ServerFrame.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(ServerFrame.class.getName())
					.log(java.util.logging.Level.SEVERE, null, ex);
		}
		// </editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new ServerFrame().setVisible(true);
			}
		});
	}

	// Variables declaration - do not modify
	private javax.swing.JButton btnBrowse;
	private javax.swing.JButton btnNewMap;
	private javax.swing.JButton btnSaveMap;
	private javax.swing.JButton btvStartServer;
	private javax.swing.JButton btvStopServer;
	private javax.swing.JCheckBox chBoxDisc;
	private javax.swing.JCheckBox chBoxURL;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JLabel lblMapName;
	private javax.swing.JLabel lblScale;
	private javax.swing.JPanel panelServerButtons;
	private javax.swing.JPanel pnlNewMap;
	private javax.swing.JPanel pnlNewPictureMap;
	private javax.swing.JTextField txtFieldDisc;
	private javax.swing.JTextField txtFieldMapName;
	private javax.swing.JTextField txtFieldScale;
	private javax.swing.JTextField txtFieldURL;
	private javax.swing.JButton btnPutCordinate;
	private ImagePanel pnlPicturePanel;
	private javax.swing.JButton btnSaveCoordinate;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JLabel lblQestionName;
	private javax.swing.JLabel lblQuestionInfo;
	private javax.swing.JLabel lblX;
	private javax.swing.JLabel lblYCoordinate;
	private javax.swing.JList listMaps;
	private javax.swing.JTextField txtFieldQuestionInfo;
	private javax.swing.JTextField txtFieldQuestionName;
	private javax.swing.JTextField txtFieldXCoordinate;
	private javax.swing.JTextField txtFieldYCoordinate;
	private javax.swing.GroupLayout pnlNewPictureMapLayout;
	private javax.swing.JPanel pnlCard;
	private CardLayout cardLayout;
	private DBConectivity connectivity;
	private String allMapsNameQuery;
	private String allDataForSpecificMapName;
	private DefaultListModel listModel;
	private JFrame pictureJFrame;
	private javax.swing.GroupLayout pnlNewMapLayout;

	// End of variables declaration
}
