package client.server.pack;

import geograph.pack.ClientFrame;
import geograph.pack.GeoImages;
import geograph.pack.PlayingDatePointCoordinates;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.ResultSet;

import javax.swing.JFrame;

import com.sun.xml.internal.messaging.saaj.packaging.mime.util.QEncoderStream;

public class Client {
	Socket client = null;
	ObjectInputStream readObjectInputStream = null;
	ObjectOutputStream writeObjectOutputStrem = null;

	public void connectToServer(String hostAddress, int port) {
		try {
			client = new Socket(hostAddress, port);
			readObjectInputStream = new ObjectInputStream(
					client.getInputStream());
			writeObjectOutputStrem = new ObjectOutputStream(
					client.getOutputStream());
		} catch (UnknownHostException e) {
			System.out.println("Host name is unkown.");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void readWrite(ClientFrame clientFrame) {
		// Reading GeoImages array
		while (true) {
			String mapsNameArray[];
			try {
				GeoImages[] images = (GeoImages[]) readObjectInputStream
						.readObject();
				// Make array with maps' names
				mapsNameArray = new String[images.length];
				for (int i = 0; i < images.length; i++) {
					mapsNameArray[i] = images[i].getName();
				}
				clientFrame.setListMapNames(mapsNameArray);

				PlayingDatePointCoordinates[] coordinates = (PlayingDatePointCoordinates[]) readObjectInputStream
						.readObject();
				clientFrame.playGame(coordinates);

			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("Client is closed");
			}
		}
	}

	public void writeToServer(String[] data) {

		try {
			writeObjectOutputStrem.writeObject(data);
			writeObjectOutputStrem.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void tearDownConnection() {
		try {
			if (client != null) {
				client.close();
			}
			if (readObjectInputStream != null) {
				readObjectInputStream.close();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
