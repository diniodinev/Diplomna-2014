package geograph.pack;

import java.awt.Point;

import javax.swing.JProgressBar;

public class ProgressBarWork implements Runnable {

	JProgressBar progressBar = null;

	public ProgressBarWork(JProgressBar progressBar) {
		this.progressBar = progressBar;

	}

	@Override
	public void run() {
		synchronized (ClientFrame.clickedPoint) {
			int i;
			for (i = 0; i <= 100; i++) {

				if (ClientFrame.clickedPoint.getX() == 0
						&& ClientFrame.clickedPoint.getY() == 0) {
					progressBar.setValue(i);
				} else {
					i = 101;
					ClientFrame.clickedPoint.notifyAll();
					break;
				}
				try {
					Thread.sleep(100);
					if (i == 100) {
						break;
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			// If nothing clicked
			if (i == 100) {
				ClientFrame.setPoint(new Point(99999, 99999));
				ClientFrame.clickedPoint.notifyAll();
			}
		}
	}
}
