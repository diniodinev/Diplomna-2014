package client.server.pack;

import geograph.pack.DBConectivity;
import geograph.pack.DBImage;
import geograph.pack.GeoImages;
import geograph.pack.PlayingDatePointCoordinates;

import java.awt.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

public class PooledConnectionHandler implements Runnable {

	private ObjectOutputStream writeObjectStream = null;
	private ObjectInputStream readObjectStream = null;
	private DBConectivity connectivity = null;
	private String allMapsNameQuery = new String(
			"select name, length, data, mapScale from geoImage");

	private GeoImages mapNamesArray[];

	protected Socket connection = null;
	protected static LinkedList pool = new LinkedList();

	public PooledConnectionHandler() {
		connectivity = new DBConectivity();
		connectivity.connect();
	}

	public void handleConnection() {
		ResultSet mapNames = connectivity.executeDBQuery(allMapsNameQuery);

		mapNamesArray = geoImagesResultSet(mapNames);
		try {
			writeObjectStream = new ObjectOutputStream(
					connection.getOutputStream());
			readObjectStream = new ObjectInputStream(
					connection.getInputStream());
			while (true) {
				writeObjectStream.writeObject(mapNamesArray);
				writeObjectStream.flush();
				writeObjectStream.writeObject(waitForNameAndMapNames());
				writeObjectStream.flush();
			}

			// System.out.println(waitForNameAndMapNames()[2].getQesName());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Client Close");
		}
	}

	@Override
	public void run() {
		while (true) {
			synchronized (pool) {
				while (pool.isEmpty()) {
					try {
						pool.wait();
					} catch (InterruptedException e) {
						return;
					}
				}
				connection = (Socket) pool.remove(0);
			}
			handleConnection();
		}

	}

	public static void processRequest(Socket requestToHandle) {
		synchronized (pool) {
			pool.add(pool.size(), requestToHandle);
			pool.notifyAll();
		}
	}

	private void tearDownConnection() {
		try {
			writeObjectStream.close();
			connection.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// Non connection Methods
	private PlayingDatePointCoordinates[] waitForNameAndMapNames() {
		String[] names = new String[2];
		PlayingDatePointCoordinates coordinates[] = null;
		try {
			names = (String[]) readObjectStream.readObject();
			coordinates = connectivity.selectTenTuplesForSpecificMap(names[0]);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("One client is closed");
		}
		return coordinates;

	}

	public GeoImages[] geoImagesResultSet(ResultSet resultSet) {
		GeoImages[] geoImagesData = null;
		int counter = 0;
		if (resultSet == null) {
			return new GeoImages[0];
		}
		try {
			geoImagesData = new GeoImages[getRowCount(resultSet)];
			while (resultSet.next()) {
				geoImagesData[counter] = new GeoImages();
				geoImagesData[counter].setName(resultSet.getString(1));
				geoImagesData[counter].setLength(resultSet.getInt(2));
				geoImagesData[counter].setData(resultSet.getBytes(3));
				geoImagesData[counter].setMapScale(resultSet.getInt(4));
				counter++;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return geoImagesData;
	}

	public int getRowCount(ResultSet set) throws SQLException {
		int rowCount;
		int currentRow = set.getRow(); // Get current row
		rowCount = set.last() ? set.getRow() : 0; // Determine number of rows
		if (currentRow == 0) // If there was no current row
			set.beforeFirst(); // We want next() to go to first row
		else
			// If there WAS a current row
			set.absolute(currentRow); // Restore it
		return rowCount;
	}
}
