package geograph.pack;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PlayingDatePointCoordinates implements Serializable{
	// [xCoordinate] [int] NOT NULL,
	// [yCoordinate] [int] NOT NULL,
	// [qesName] [varchar](200) NOT NULL,
	// [qesInfo] [varchar](500) NOT NULL,
	// [map] [varchar](100) NOT NULL,

	private int xCoordinate;
	private int yCoordinate;
	private String qesName;
	private String qesInfo;
	private String map;

	public PlayingDatePointCoordinates(int xCoordinate, int yCoordinate,
			String qesName, String qesInfo, String map) {
		if (qesName != null && qesInfo != null && map != null) {
			this.xCoordinate = xCoordinate;
			this.yCoordinate = yCoordinate;
			this.qesName = qesName;
			this.qesInfo = qesInfo;
			this.map = map;
		}

	}

	public PlayingDatePointCoordinates() {

	}

	public PlayingDatePointCoordinates(ResultSet resultSet) {
		// name, length, data, mapScale
		try {
			if (resultSet.next()) {
				//miss id
				setxCoordinate(resultSet.getInt(2));
				setyCoordinate(resultSet.getInt(3));
				setQesName(resultSet.getString(4));
				setQesInfo(resultSet.getString(5));
				setMap(resultSet.getString(6));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public int getxCoordinate() {
		return xCoordinate;
	}

	public void setxCoordinate(int xCoordinate) {
		this.xCoordinate = xCoordinate;
	}

	public int getyCoordinate() {
		return yCoordinate;
	}

	public void setyCoordinate(int yCoordinate) {
		this.yCoordinate = yCoordinate;
	}

	public String getQesName() {
		return qesName;
	}

	public void setQesName(String qesName) {
		this.qesName = (qesName != null) ? qesName : "";
	}

	public String getQesInfo() {
		return qesInfo;
	}

	public void setQesInfo(String qesInfo) {
		this.qesInfo = (qesInfo != null) ? qesInfo : "";
	}

	public String getMap() {
		return map;
	}

	public void setMap(String map) {
		this.map = (map != null) ? map : "";
	}

}
