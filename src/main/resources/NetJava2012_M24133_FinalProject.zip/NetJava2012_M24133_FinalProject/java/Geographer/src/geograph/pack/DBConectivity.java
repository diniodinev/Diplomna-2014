package geograph.pack;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author Cannibal
 * 
 */
public class DBConectivity {
	private String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	private String mssqlUrl = "jdbc:sqlserver://localhost:1433;databaseName=DBGeographer;integratedSecurity=true;";
	private Connection con = null;
	private Statement statement = null;

	public DBConectivity() {

	}

	public void connect() {
		try {
			// Load the JDBC driver
			Class.forName(driverName);
			con = DriverManager.getConnection(mssqlUrl);
			statement = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			//
			// ResultSet resultSet = statement
			// .executeQuery("SELECT * FROM Exam.dbo.DI where Mark>5");
			// ResultSetMetaData resultSetMetadata = resultSet.getMetaData();
			// System.out.println("id" + "\t" + "studentName" + "\t" +
			// "examMark"
			// + "\t" + "questionNumbers");
			// while (resultSet.next()) {
			// int id = resultSet.getInt(1);
			// String studentName = resultSet.getString(2);
			// double examMark = resultSet.getDouble(3);
			// String questionNumbers = resultSet.getNString(4);
			// System.out.println(id + "\t" + studentName + "\t" + examMark
			// + "\t" + questionNumbers);
			//
			// }

		} catch (ClassNotFoundException e) {
			// Could not find the database driver
			e.printStackTrace();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * @param The
	 *            query that want to execute
	 * @return ResultSet if the operation is select or null if the operation is
	 *         insert, delete or update or if there is no results
	 */
	public ResultSet executeDBQuery(String query) {

		ResultSet resultQuery = null;
		boolean resultFromQuery = false;
		try {
			resultFromQuery = statement.execute(query);

			if (resultFromQuery) {
				resultQuery = statement.getResultSet();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultQuery;
	}

	public Connection getConnection() {
		return con;
	}

	public ResultSet selectInfoForSpecificMap(String mapName) {
		StringBuilder query;
		ResultSet result = null;
		query = new StringBuilder(
				"select name, length, data, mapScale from geoImage where name='");
		query.append(mapName).append("'");
		try {
			result = statement.executeQuery(query.toString());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	public int getRowCount(ResultSet set) throws SQLException {
		int rowCount;
		int currentRow = set.getRow(); // Get current row
		rowCount = set.last() ? set.getRow() : 0; // Determine number of rows
		if (currentRow == 0) // If there was no current row
			set.beforeFirst(); // We want next() to go to first row
		else
			// If there WAS a current row
			set.absolute(currentRow); // Restore it
		return rowCount;
	}

	public PlayingDatePointCoordinates[] selectTenTuplesForSpecificMap(
			String mapName) {
		StringBuilder query;
		ResultSet result = null;
		PlayingDatePointCoordinates[] resultCoordinates=null;
		int currentCoordinateNumber=0;
		query = new StringBuilder("select top 10  id,xCoordinate,yCoordinate,"
				+ "qesName,qesInfo,map from PlayingDate where map='");
		query.append(mapName).append("'").append(" order by newid()");
		try {
			result = statement.executeQuery(query.toString());
			resultCoordinates = new PlayingDatePointCoordinates[getRowCount(result)];
			while(result.next()){
				resultCoordinates[currentCoordinateNumber]=new PlayingDatePointCoordinates();
				resultCoordinates[currentCoordinateNumber].setxCoordinate(result.getInt(2));
				resultCoordinates[currentCoordinateNumber].setyCoordinate(result.getInt(3));
				resultCoordinates[currentCoordinateNumber].setQesName(result.getString(4));
				resultCoordinates[currentCoordinateNumber].setQesInfo(result.getString(5));
				resultCoordinates[currentCoordinateNumber].setMap(result.getString(6));
				currentCoordinateNumber++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultCoordinates;
	}
}
