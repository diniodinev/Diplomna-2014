package geograph.pack;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class DBPlayingData {

	public void insertData(Connection conn, int xCoordinate, int yCoordinate,
			String qesName, String qesInfo, String map) {

		if (conn == null || qesName == null || qesInfo == null || map == null) {
			return;
		}

		String query;
		PreparedStatement pstmt;

		try {
			query = ("insert into PlayingDate(xCoordinate,yCoordinate,qesName,qesInfo,map) values(?,?,?,?,?)");
			pstmt = conn.prepareStatement(query);

			pstmt.setInt(1, xCoordinate);
			pstmt.setInt(2, yCoordinate);
			
			pstmt.setString(3,qesName);
			pstmt.setString(4,qesInfo);
			pstmt.setString(5,map);
			
			pstmt.executeUpdate();
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null,
					"Error while writeing in DB. ",
					"Error", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}

	}
}
