package geograph.pack;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class DBImage {
	FileInputStream fisFileInputStream;

	// name varchar(100) NOT NULL PRIMARY KEY,
	// length int NOT NULL CHECK (length >0),
	// data varBinary(MAX) NOT NULL,
	// mapScale smallint NOT NULL CHECK (mapScale >0)
	// name, length, data, mapScale

	/**
	 * Insert image and its related information into the DB, if some of the
	 * parameters are null or incorrect nothing is inserted into the DB GeoImage
	 * 
	 * @param conn
	 *            The name of connection which will be used to connect to DB
	 * @param img
	 *            URL of image which we want to use as source for the image
	 * @param mapName
	 *            The name of the image that we want to store in DB
	 * @param scale
	 *            The scale of the map
	 */
	public void insertImage(Connection conn, String img, String mapName,
			int scale) {

		if (conn == null || img == null || mapName == null || scale <= 0) {
			return;
		}

		int lengthOfPictureFile;
		String query;
		PreparedStatement pstmt;
		File file;

		try {
			if (isURLFileValid(img)) {
				file = getPicture(img);
			} else {
				file = new File(img);
			}

			fisFileInputStream = new FileInputStream(file);
			lengthOfPictureFile = (int) file.length();

			query = ("insert into GeoImage VALUES(?,?,?,?)");
			pstmt = conn.prepareStatement(query);
			// setValues
			pstmt.setString(1, mapName);

			// Get picture Sizes
			BufferedImage bimg = ImageIO.read(file);
			int width = bimg.getWidth();
			int height = bimg.getHeight();
			if (width != 624 || height != 403) {
				JOptionPane.showMessageDialog(null,
						"The picture size MUST be 624 x 403 px.", "Error",
						JOptionPane.ERROR_MESSAGE);
				return;
			}

			pstmt.setInt(2, lengthOfPictureFile);
			// Method used to insert a stream of bytes
			pstmt.setBinaryStream(3, fisFileInputStream, lengthOfPictureFile);
			pstmt.setInt(4, scale);
			pstmt.executeUpdate();
			JOptionPane.showMessageDialog(null, "The map is saved", "Success",
					JOptionPane.INFORMATION_MESSAGE);
		} catch (FileNotFoundException ex) {

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,
					"Error while writeing in DB. The map name"
							+ "can be dublicate or other issue can occure.",
					"Error", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		} finally {
			try {
				if (fisFileInputStream != null) {
					fisFileInputStream.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private File getPicture(String imageUrl) {
		BufferedImage image = null;
		File pictureFile = new File("file");
		try {

			URL url = new URL(imageUrl);
			image = ImageIO.read(url);

			ImageIO.write(image, "jpg", pictureFile);
			ImageIO.write(image, "jpeg", pictureFile);
			ImageIO.write(image, "bmp", pictureFile);

		} catch (IOException e) {
			e.printStackTrace();
		}
		return pictureFile;
	}

	private boolean isURLFileValid(String urlLocation) {
		try {
			URL url = new URL(urlLocation);
			URLConnection conn = url.openConnection();
			conn.connect();
			String urlType = conn.getContentType();
			if (urlType.contains("image/jpeg") || urlType.contains("image/jpg")
					|| urlType.contains("image/bmp")) {
				return true;
			}
		} catch (IOException e) {
			return false;
		}
		return false;
	}

	/**
	 * @param conn
	 *            Connection to the DB
	 * @param mapName
	 *            The name of the map that data we want to take
	 * @return GeoImages object with the information taken from the DB for the
	 *         specific <code>mapName</code>
	 * @throws TooManyResultsException
	 *             If the <code>ResultSet</code> has more than one row.
	 */
	public GeoImages getImageData(Connection conn, String mapName) {

		byte[] fileBytes;
		String query;
		GeoImages geoImagesQueryResult = null;
		try {
			query = "select name, length, data, mapScale from GeoImage where name='"
					+ mapName + "'";
			Statement state = conn.createStatement(
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = state.executeQuery(query);
			if (getRowCount(rs) != 1) {
				throw new TooManyResultsException(
						"The query returns more than one results.");
			} else {
				geoImagesQueryResult = new GeoImages(rs);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return geoImagesQueryResult;
	}

	// ----------------------------------------------------------------------------------------------
	/**
	 * Determines the number of rows in a <code>ResultSet</code>. Upon exit, if
	 * the cursor was not currently on a row, it is just before the first row in
	 * the result set (a call to {@link ResultSet#next()} will go to the first
	 * row).
	 * 
	 * @param set
	 *            The <code>ResultSet</code> to check (must be scrollable).
	 * @return The number of rows.
	 * @throws SQLException
	 *             If the <code>ResultSet</code> is not scrollable.
	 * @see #hasSingleRow(ResultSet)
	 */
	public int getRowCount(ResultSet set) throws SQLException {
		int rowCount;
		int currentRow = set.getRow(); // Get current row
		rowCount = set.last() ? set.getRow() : 0; // Determine number of rows
		if (currentRow == 0) // If there was no current row
			set.beforeFirst(); // We want next() to go to first row
		else
			// If there WAS a current row
			set.absolute(currentRow); // Restore it
		return rowCount;
	}

	public int numberOfDigits(int number) {
		int counter = 0;
		while (number > 0) {
			number /= 10;
			counter++;
		}
		return counter;
	}

	
}
