package geograph.pack;

import java.awt.Point;

import client.server.pack.Client;

public class ClientStart {
	public static ClientFrame clientFrame = new ClientFrame();
	public static Client client = new Client();

	public ClientStart() {

	}

	public static void main(String[] args) {
		
		clientFrame.run(client);
		client.connectToServer("127.0.0.1", 3000);
		client.readWrite(clientFrame);
	}

}
