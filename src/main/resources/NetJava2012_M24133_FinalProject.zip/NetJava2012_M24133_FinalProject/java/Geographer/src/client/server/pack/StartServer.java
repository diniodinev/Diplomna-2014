package client.server.pack;

public class StartServer implements Runnable {

	/**
	 * @param args
	 */

	@Override
	public void run() {

		Server probenServer = new Server(3000, 1);
		System.out.println("Server is running");
		probenServer.setUpHandlers();
		probenServer.acceptConnection();

	}

}
