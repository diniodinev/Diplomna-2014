package parcelpack;

public class Parcel3 {

    private class PContents implements Contents {

        private int i = 11;

        public int values() {
            return i;
        }
    }//end of PContents

    protected class PDestination implements Destination {

        private String label;

        public PDestination(String whereTo) {
            label = whereTo;
        }

        public String readLabel() {
            return label;
        }
    }

    public Contents count() {
        return new PContents();
    }

    public Destination dest(String dest) {
        return new PDestination(dest);
    }
}//end of Parcel3

