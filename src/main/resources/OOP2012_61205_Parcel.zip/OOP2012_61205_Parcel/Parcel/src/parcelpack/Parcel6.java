package parcelpack;

public class Parcel6 {

}
