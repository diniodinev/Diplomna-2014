package parcelpack;

public interface Contents {

    public int values();
}
