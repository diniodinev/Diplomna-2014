package parcelpack;

public interface Destination {
    String readLabel();

}
