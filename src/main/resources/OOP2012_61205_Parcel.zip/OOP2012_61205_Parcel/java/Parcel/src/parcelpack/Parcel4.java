package parcelpack;

public class Parcel4 {

    public Destination dest(String s) {


        class PDestination implements Destination {

            private String label;

            public PDestination(String whereTo) {
                label = whereTo;
            }

            public String readLabel() {
                return label;
            }
        }//edn of PDestination
        return new PDestination(s);
    }
}//end of PArcel4

