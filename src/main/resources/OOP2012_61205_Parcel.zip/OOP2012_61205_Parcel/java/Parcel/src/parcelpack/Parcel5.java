package parcelpack;

public class Parcel5 {

    private void internalTracking(boolean b) {
        if (b) {
            class TrackingSlip {

                private String id;

                public TrackingSlip(String s) {
                    this.id = s;
                }

                public String getSlip() {
                    return id;
                }
            }//end of TrackingSlip
            TrackingSlip ts = new TrackingSlip("slip");
            String s = ts.getSlip();
            System.out.println(s);

        }


    }

    public void track() {
        internalTracking(true);

    }
}
