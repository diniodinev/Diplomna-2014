package parcelpack;

public class ParcelTest {

    public static void main(String[] args) {
        Parcel5 p5=new Parcel5();
        //304
    }
}
